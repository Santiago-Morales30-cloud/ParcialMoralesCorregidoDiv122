package parcial_moralesdiv122;


public interface Entrenable {
   
    String entrenar();
    
    
}
