package parcial_moralesdiv122;

/**
 * Aventurero especializado en precision y ataque a distancia.
 */
public class Arquero extends Aventurero implements Atacante, Entrenable{
    
    private final int precision;

    public Arquero(String codigo, String nombre, TipoRango rango, int precision) {
        super(codigo, nombre, rango);
        validarPositivo(precision, "La precision.");
        this.precision = precision;
    }

    
    public int getPrecision() {
        return precision;
    }


    
    @Override
    public int calcularPoderCombate() {
        return precision * 3;
    }

    
    @Override
    public String realizarAtaque() {
        return getNombre() + " dispara una flecha.";
    }

    @Override
    public String entrenar() {
        return getNombre() + " practica tiro al blanco.";
    }

    @Override
    public String toString() {
        return "Arquero{" + descripcionComun() + "precision=" + precision + '}';
    }
    
    
    
    
}
