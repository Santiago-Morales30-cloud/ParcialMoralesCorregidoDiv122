package parcial_moralesdiv122;

import java.util.Objects;

/**
 * Representa un aventurero del gremio.
 */


public abstract class Aventurero {
    
    private final String codigo;
    private final String nombre;
    private final TipoRango rango;

    public Aventurero(String codigo, String nombre, TipoRango rango) {
        validarTexto(codigo, "El codigo es obligatorio.");
        validarTexto(nombre, "El nombre es obligatorio.");
        validarRango(rango);
        this.codigo = codigo;
        this.nombre = nombre;
        this.rango = rango;
    }
    
    
    protected static void validarTexto(String texto, String mensaje){
        if (texto == null || texto.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }

    private static void validarRango(TipoRango rango){
        if (rango == null){
            throw new IllegalArgumentException("El rango es obligatorio.");
        }
    }
    
    
    protected static void validarPositivo(int valor, String descripcion){
        if (valor <= 0){
            throw new IllegalArgumentException(descripcion + " debe ser mayor que cero.");
        }
    }
    

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoRango getRango() {
        return rango;
    }

    
    /**
     * Calcula el poder de combate segun el tipo concreto.
     */
    
    public abstract int calcularPoderCombate();
    
    
    protected String descripcionComun(){
        return "codigo=" + codigo + ", nombre=" + nombre + ", rango=" + rango;
    }
    
    
    @Override
    public int hashCode() {
        return Objects.hash(codigo, nombre);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Aventurero otro)){
            return false;
        }
        return codigo.equals(otro.codigo) && nombre.equals(otro.nombre);
    }

    @Override
    public String toString() {
        return "Aventurero{" + "codigo=" + codigo + ", nombre=" + nombre + ", rango=" + rango + '}';
    }
    
    
    
}
