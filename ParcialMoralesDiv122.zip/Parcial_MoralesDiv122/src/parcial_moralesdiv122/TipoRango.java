package parcial_moralesdiv122;


public enum TipoRango {
    
    BRONCE,
    PLATA,
    ORO;
    
    
}
