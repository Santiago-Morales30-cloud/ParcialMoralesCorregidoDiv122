package parcial_moralesdiv122;


public interface Atacante {
    
    String realizarAtaque();
    
    
}
