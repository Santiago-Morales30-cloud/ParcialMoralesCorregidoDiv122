package parcial_moralesdiv122;

/**
 * Aventurero especializado en fuerza y ataque a melee.
 */
public class Guerrero extends Aventurero implements Atacante, Entrenable{
    
    private final int fuerza;
    
    public Guerrero(String codigo, String nombre, TipoRango rango, int fuerza) {
        super(codigo, nombre, rango);
        validarPositivo(fuerza, "La fuerza");
        this.fuerza = fuerza;
    }

    
    public int getFuerza() {
        return fuerza;
    }

    
    @Override
    public int calcularPoderCombate() {
        return fuerza * 2;
    }

    @Override
    public String realizarAtaque() {
        return getNombre() + " ataca con su espada.";
    }

    @Override
    public String entrenar() {
        return getNombre() + " practica combate cuerpo a cuerpo.";
    }

    @Override
    public String toString() {
        return "Guerrero{" + descripcionComun() + "fuerza=" + fuerza + '}';
    }
    
    
    
    
}
