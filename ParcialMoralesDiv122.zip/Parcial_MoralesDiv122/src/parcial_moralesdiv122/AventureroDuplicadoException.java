package parcial_moralesdiv122;

public class AventureroDuplicadoException extends Exception {

    public final static String DEFAULT_MESSAGE = "Ya existe un aventurero con el mismo codigo y nombre.";

    public AventureroDuplicadoException() {
        this(DEFAULT_MESSAGE);
    }

    public AventureroDuplicadoException(String mensaje) {
        super(mensaje);
    }

}
