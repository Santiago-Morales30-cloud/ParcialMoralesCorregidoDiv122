package parcial_moralesdiv122;

/**
 * Aventurero especializado en mana y ataque magico.
 */

public class Mago extends Aventurero implements Atacante{
    
    private final int mana;

    public Mago(String codigo, String nombre, TipoRango rango, int mana) {
        super(codigo, nombre, rango);
        validarPositivo(mana, "El mana");
        this.mana = mana;
    }

    public int getMana() {
        return mana;
    }

    
    @Override
    public int calcularPoderCombate() {
        return mana + 10;
    }

    @Override
    public String realizarAtaque() {
        return getNombre() + " lanza un hechizo.";
    }

    @Override
    public String toString() {
        return "Mago{" + descripcionComun() + "mana=" + mana + '}';
    }
    
    
    
    
    
}
