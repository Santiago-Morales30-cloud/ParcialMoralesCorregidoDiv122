package parcial_moralesdiv122;

import java.util.List;


public class Parcial_MoralesDiv122 {

    
    public static void main(String[] args) {
        
         GremioAventureros gremio = new GremioAventureros("Guardianes de Eldoria"); 
        
        try{
            gremio.agregarAventurero(new Guerrero("G-01", "Arin", TipoRango.ORO, 30)); 
            gremio.agregarAventurero(new Mago("M-02", "Lyra", TipoRango.PLATA, 45)); 
            gremio.agregarAventurero(new Arquero("A-03", "Nox", TipoRango.BRONCE, 18)); 
            gremio.agregarAventurero(new Guerrero("G-04", "Borin", TipoRango.PLATA, 20)); 
            gremio.agregarAventurero(new Mago("G-01", "Arin", TipoRango.BRONCE, 99)); 
        } catch (AventureroDuplicadoException e){ // No se porque me tira error
            System.out.println("No se puede agregar: " + e.getMessage());
        }  
       
        
        System.out.println("Aventureros registrados:"); 
        mostrarAventureros(gremio.obtenerAventureros()); 
        System.out.println("\nAtaques:"); 
        mostrarAtaques(gremio.obtenerAventureros()); 
        System.out.println("\nEntrenamientos:"); 
        mostrarEntrenamientos(gremio.obtenerAventureros()); 
        System.out.println("\nPoder de combate:"); 
        mostrarPoderes(gremio.obtenerAventureros()); 
        System.out.println("\nAventureros de rango PLATA:"); 
        mostrarAventureros(gremio.filtrarPorRango(TipoRango.PLATA)); 
        System.out.println("\nAventureros con poder >= 55:"); 
        mostrarAventureros(gremio.obtenerAventurerosPoderosos(55)); 
 
    } 
    private static void mostrarAventureros(List<Aventurero> aventureros) {        
        for (Aventurero aventurero : aventureros){
            System.out.println(aventurero);
        }
        
    } 
 
    private static void mostrarAtaques(List<Aventurero> aventureros) { 
        for (Aventurero aventurero : aventureros){
            if (aventurero instanceof Atacante atacante){
                System.out.println(atacante.realizarAtaque());
            }
        }
    } 
 
    private static void mostrarEntrenamientos(List<Aventurero> aventureros) { 
        for (Aventurero aventurero : aventureros){
            if(aventurero instanceof Entrenable entrenable){
                System.out.println(entrenable.entrenar());
            }else {
                System.out.println(aventurero.getNombre() + " no puede realizar entrenamiento especial.");
            }
        }
    } 
 
    private static void mostrarPoderes(List<Aventurero> aventureros) { 
        for (Aventurero aventurero : aventureros){
            System.out.println(aventurero.getNombre() + ": " + aventurero.calcularPoderCombate());
        }
    }
        
    
}
