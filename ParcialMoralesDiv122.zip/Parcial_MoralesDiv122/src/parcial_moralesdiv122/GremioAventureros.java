package parcial_moralesdiv122;

import java.util.ArrayList;
import java.util.List;

/**
 * Administra el registro de aventureros de un gremio.
 */

public class GremioAventureros {
    
    private final String nombre;
    private final List<Aventurero> aventureros;

    
    public GremioAventureros(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        this.aventureros = new ArrayList<>();
    }

    private static void validarNombre(String nombre){
        if (nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre del gremio es obligatorio.");
        }
    }
    
    
    
    public String getNombre() {
        return nombre;
    }


    
    private static void validarNuevoAventurero(Aventurero aventurero){
        if (aventurero == null){
            throw new IllegalArgumentException("El aventurero no puede ser null.");
        }
    }
    
    
    /**
     * Agrega un aventurero si no existe otro considerado igual.
     */
    public void agregarAventurero(Aventurero nuevoAventurero) throws AventureroDuplicadoException {
        validarNuevoAventurero(nuevoAventurero);
        if(aventureros.contains(nuevoAventurero)){
            throw new AventureroDuplicadoException("Ya existe un aventurero con codigo '" + nuevoAventurero.getCodigo() + 
                    "' y el nombre '" + nuevoAventurero.getNombre() + "'.");
        }
        aventureros.add(nuevoAventurero);
    }
    
    /**
     * Devuelve una copia, para no exponer la coleccion interna.
     */
    public List<Aventurero> obtenerAventureros(){
        return new ArrayList<>(aventureros);
    
    }
    
    
    private static void validarRango(TipoRango rango){
        if (rango == null){
            throw new IllegalArgumentException("El rango es obligatorio.");
        }
    }
    
    
    /**
     * 
     * Deuelve los aventureros cuyo rango coincide con el recibido.
     */
    public List<Aventurero> filtrarPorRango(TipoRango rango){
        validarRango(rango);
        List<Aventurero> resultado = new ArrayList<>();
        for (Aventurero aventurero : aventureros){
            if(aventurero.getRango() == rango){
                resultado.add(aventurero);
            }
        }
        return resultado;
    }
    
    
    private static void validarPoderMinimo(int minimo){
        if (minimo <= 0){
            throw new IllegalArgumentException("El poder minimo debe ser positivo.");
        }
    }
    
    
    /**
     * Devuelve los aventureros con poder de combate >= al minimo.
     */
    
    public List<Aventurero> obtenerAventurerosPoderosos(int minimo){
        validarPoderMinimo(minimo);
        List<Aventurero> resultado = new ArrayList<>();
        for (Aventurero aventurero : aventureros){
            if(aventurero.calcularPoderCombate() >= minimo){
                resultado.add(aventurero);
            }
        }
        return resultado;
    }
    
    
}
